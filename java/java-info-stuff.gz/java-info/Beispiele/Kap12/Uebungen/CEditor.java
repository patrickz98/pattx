// Ein (nicht ganz) einfacher Text-Editor
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.print.*; 
import java.text.*; 

public class CEditor extends JFrame  {
  final int ZEILEN  = 100;   //  Konstanten f�r die Gr��e 
  final int SPALTEN = 400;   // der Textfl�che

  // globale Variablen innerhalb der Klasse
  private String m_dateiname;  // zu ladende/speichernde Datei
  private String m_aktText;    // aktueller Text in der TextArea
  private JTextArea m_textanzeige;  // Text-Komponente
  private JComboBox m_fonts,m_styles;  // Auswahl von Font, Stil 
  private JComboBox m_farben;          // und Farbe
  private Hashtable<String,Action> m_befehle;
  private String suchstring;
  private int    index;

  public static void main(String[] args) {
    // eine Instanz der Klasse anlegen und anzeigen
    CEditor e = new CEditor("Texteditor");

    // Position auf Bildschirm vorgeben
    e.setLocation(100,100);
    e.pack();
    e.setVisible(true);
  }

  // Im Konstruktur die Benutzerberfl�che aufbauen
  CEditor(String titel) {
    super(titel);

    // Men�leiste  mit Men�s anlegen
    JMenuBar menueleiste = new JMenuBar();
    setJMenuBar(menueleiste);

    JMenu menu1 = new JMenu("Datei");
    JMenuItem item1_1 = new JMenuItem("Datei laden");
    JMenuItem item1_2 = new JMenuItem("Datei speichern");
    JMenuItem item1_3 = new JMenuItem("Datei drucken"); 
    JMenuItem item1_4 = new JMenuItem("Programm beenden");
    menu1.add(item1_1);
    menu1.add(item1_2);
    menu1.add(item1_3);
    menu1.add(item1_4);
    menueleiste.add(menu1);

    JMenu menu2 = new JMenu("Bearbeiten");
    JMenuItem item2_1 = new JMenuItem("Ausscheiden");
    JMenuItem item2_2 = new JMenuItem("Kopieren");
    JMenuItem item2_3 = new JMenuItem("Einf�gen");
    menu2.add(item2_1);
    menu2.add(item2_2);
    menu2.add(item2_3);
    menueleiste.add(menu2);

    JMenu menu3 = new JMenu("Suchen");
    JMenuItem item3_1 = new JMenuItem("String suchen");
    JMenuItem item3_2 = new JMenuItem("Weitersuchen");
    menu3.add(item3_1);
    menu3.add(item3_2);
    menueleiste.add(menu3);

    // Panel f�r den Textbereich und die Auswahlfelder
    JPanel p_au�en = new JPanel();
    p_au�en.setLayout(new BorderLayout());
      
    // Text-Komponente anlegen
    m_textanzeige = new JTextArea(ZEILEN, SPALTEN);
    m_textanzeige.setEditable(true);

    // Textkomponente scrollbar machen
    JScrollPane scroll = new JScrollPane();
    scroll.getViewport().add(m_textanzeige);      

    // Inneres Panel f�r die Auswahlm�glichkeiten 
    JPanel p_innen = new JPanel();
    p_innen.setLayout(new GridLayout(1,4));

    // Auswahl von Schriftarten
    String[] fontNames;
    fontNames  = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
    m_fonts = new JComboBox();
    for(int i = 0; i < fontNames.length; i++)
       m_fonts.addItem(fontNames[i]); 
    

    // Auswahl von Schriftstilen
    m_styles = new JComboBox();
    m_styles.addItem("normal");
    m_styles.addItem("kursiv");
    m_styles.addItem("fett");
  
    // Auswahl von Schriftfarben
    m_farben = new JComboBox();
    m_farben.addItem("Schwarz");          
    m_farben.addItem("Rot");
    m_farben.addItem("Gr�n");
    m_farben.addItem("Blau");
    m_farben.addItem("Gelb");
    m_farben.addItem("Cyan");
    m_farben.addItem("Magenta");
      
    p_innen.add(m_fonts);  
    p_innen.add(m_styles);
    p_innen.add(m_farben);
   
    p_au�en.setPreferredSize(new Dimension(500,400));
    p_au�en.add("Center",scroll);  
    p_au�en.add("North",p_innen); 

    // Panel zur Fensterklasse hinzuf�gen
    add(p_au�en);                
    
    // Font, Farbe und Schriftstil festlegen  
    m_fonts.setSelectedItem("SansSerif");
    m_styles.setSelectedItem("normal");                     
    m_farben.setSelectedIndex(0);          
    fontAktualisieren(); 

 
    // Die verschiedenen Adapterklassen f�r das Maus Handling
    class CMeinItemAdapter implements ItemListener {
      public void itemStateChanged(ItemEvent e) {
         fontAktualisieren();
      }   
    } 
      
    class CMeinActionLauscher implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         String label;

         label = e.getActionCommand();

         if(label.equals("Datei laden"))
           dateiLaden();

         if(label.equals("Datei speichern"))
           dateiSpeichern();

         if(label.equals("Datei drucken"))
           dateiDrucken();

         if(label.equals("Programm beenden"))
           System.exit(0);              
          
         if(label.equals("String suchen"))
           stringSuchen(null, 0);      
           
         if(label.equals("Weitersuchen"))
           stringSuchen(suchstring, index);      
      }   
    } 

    // Fenster schlie�en = Anwendung beenden
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 
   
    // Die Instanz der Adapterklasse f�r den ActionListener 
    // brauchen wir mehrmals, daher erzeugen wir nur eine Instanz                            
    // und verwenden sie mehrfach; das spart ein bi�chen Speicher
    CMeinActionLauscher  actionlistener = 
                                       new CMeinActionLauscher();
    item1_1.addActionListener(actionlistener);
    item1_2.addActionListener(actionlistener);
    item1_3.addActionListener(actionlistener);
    item1_4.addActionListener(actionlistener);
    item3_1.addActionListener(actionlistener);
    item3_2.addActionListener(actionlistener);
   
    // Genauso bei dem Lauschobjekt f�r die Items
    CMeinItemAdapter itemlistener = new CMeinItemAdapter();
    m_fonts.addItemListener(itemlistener);
    m_styles.addItemListener(itemlistener);
    m_farben.addItemListener(itemlistener);

    // Befehle f�r die Zwischenablage
    // erzeuge Action-Tabelle
    m_befehle = new Hashtable<String,Action>();
    Action[] actionsArray = m_textanzeige.getActions();
    for (int i = 0; i < actionsArray.length; i++) {
       Action a = actionsArray[i];
       m_befehle.put((String) a.getValue(Action.NAME), a);
    }

    item2_1.addActionListener(m_befehle.get(
                                  DefaultEditorKit.cutAction));
    item2_2.addActionListener(m_befehle.get(
                                  DefaultEditorKit.copyAction));
    item2_3.addActionListener(m_befehle.get(
                                  DefaultEditorKit.pasteAction));

  } // Ende von Konstruktor 'CEditor' 

     
  // Den aktuellen Font ermitteln
  // Methode von CEditor
  void fontAktualisieren() {
    int fontstil;
    String farbe, fontname, style; 
    int punktgr��e;
   
    // Die zurzeit gesetzten Attribute ermitteln und setzen
    fontname = (String) m_fonts.getSelectedItem();
    style    = (String) m_styles.getSelectedItem();
    farbe    = (String) m_farben.getSelectedItem();
    
    if(farbe.equals("Schwarz"))
      m_textanzeige.setForeground(Color.black);
    
    if(farbe.equals("Rot"))                   	
       m_textanzeige.setForeground(Color.red);  	 
      
    if(farbe.equals("Gr�n"))
      m_textanzeige.setForeground(Color.green);
  
    if(farbe.equals("Blau"))
      m_textanzeige.setForeground(Color.blue);
    
    if(farbe.equals("Magenta"))
      m_textanzeige.setForeground(Color.magenta); 
    
    if(farbe.equals("Cyan"))
      m_textanzeige.setForeground(Color.cyan);
    
    if(farbe.equals("Gelb"))
      m_textanzeige.setForeground(Color.yellow);
    
  
    // Der Stil eines Fonts ist die Summe der Konstanten
    // PLAIN, ITALIC und BOLD
    fontstil = Font.PLAIN;
   
    if(style.equals("kursiv"))         
      fontstil += Font.ITALIC;  
   
    if(style.equals("fett"))
      fontstil += Font.BOLD;   	
   
    // den neuen Font aktivieren
    m_textanzeige.setFont(new Font(fontname,fontstil,14));
      
  } // Ende von 'fontAktualisieren'
   
   
  // Eine Textdatei laden
  // Methode von CEditor
  void dateiLaden() {
    FileDialog d = new FileDialog(this,"Text laden...",
                                   FileDialog.LOAD);
   
    d.setVisible(true);
    m_dateiname = d.getDirectory();
    m_dateiname += d.getFile();

    // Falls der Benutzer keine Datei ausgew�hlt hat, 
    // wird null zur�ckgegeben
    // Dann nichts weiter tun
    if(m_dateiname == null)
      return;

    // Einen Eingabestream �ffnen und die Datei laden
    StringBuffer lesepuffer= new StringBuffer(ZEILEN * SPALTEN);
    
    try {
      FileReader eingabe = new FileReader(m_dateiname);
           
      // so lange Zeichen lesen, bis das Dateiende ( = -1) 
      // erreicht ist 
      char zeichen;
      int gelesen;
      int zeilen = 0;
      boolean weiter = true;
  
      while(weiter) {
         gelesen = eingabe.read();

         if(gelesen == -1) {
           weiter = false;
           continue;
         }

         zeichen = (char) gelesen;
         lesepuffer.append(zeichen);
      }

      // Datei schlie�en
      eingabe.close();

      m_aktText = new String(lesepuffer);
      m_textanzeige.setText(m_aktText);	
      m_textanzeige.setCaretPosition(0);
    }
    catch(EOFException e) {
      // auf diese Exception haben wir ja gewartet
      // nichts weiter tun. 
    }
    catch(FileNotFoundException e) {
      System.err.println(" Datei nicht vorhanden oder lesbar!\n");
      m_dateiname = null;  
    }
    catch(IOException e) {
      // Sonst irgendwas ist schiefgegangen
      System.err.println(" Fehler beim Lesen der Datei " +
                         m_dateiname + "\n");
      m_dateiname = null;
    }
  } // Ende von 'dateiLaden' 


  // Den aktuellen Text abspeichern
  // Methode von CEditor
  void dateiSpeichern() {
    // lokale Variablen
    int zeichen,i;

    FileDialog d = new FileDialog(this,"Text speichern...",
                                  FileDialog.SAVE);
   
    d.setVisible(true);
    m_dateiname = d.getFile();

    if(m_dateiname == null)
      return;

    try {
      // Den Text nun in der Datei speichern
      FileWriter ausgabe = new FileWriter(m_dateiname);

      // den aktuellen Text ermitteln und speichern
      m_aktText = m_textanzeige.getText();
 
      for(i = 0; i < m_aktText.length(); i++) {
        zeichen = (int) m_aktText.charAt(i);
        ausgabe.write(zeichen);
      }

      // Datei schlie�en
      ausgabe.close();
    }
    catch(IOException e) {
      //  irgendwas ist schiefgegangen
      System.err.println(" Fehler beim Schreiben der Datei  " 
                         + m_dateiname + "\n");
      m_dateiname = null;
    }
  } // Ende von 'dateiSpeichern' 


  // den aktuellen Text drucken
  // Methode von CEditor 
  void dateiDrucken() {
    if (m_dateiname == null)
      m_dateiname = "Unbenannt";
      
    try {
       m_textanzeige.print(new MessageFormat(m_dateiname),
                  new MessageFormat("Seite {0}"),
                  true,                            // Druckdialog anzeigen
                  null, null, false);
    } catch (PrinterException e) {
       System.err.println(" Drucken nicht moeglich.\n");
    }
  }


  // Diese Funktion sucht einen String im Text
  // Methode von CEditor
  void stringSuchen(String suchstring, int index) {
    CFrageDialog frage;

    // Pr�fen, ob neue Suche
    // Wenn ja, Dialog aufrufen und Suchstring abfragen
    if (suchstring == null) {
       frage = new CFrageDialog(this,"Suchen");
       frage.setLocation(150,150);
       frage.pack();
       frage.setVisible(true); 
       suchstring = frage.getString();
       index = 0;
    
       if(suchstring == null)
          return;
    } else {
       // Suche hinter letztem gefundenen Vorkommen fortsetzen
       index += suchstring.length();
    }
        
    // nun suchen
    m_aktText = m_textanzeige.getText();
    index = m_aktText.indexOf(suchstring, index);

    if(index == -1) {
       JOptionPane.showMessageDialog(null,"String nicht gefunden",
                       "Meldung",JOptionPane.INFORMATION_MESSAGE);
       index = 0;
       suchstring = null;
    } else
       // Den String hervorheben
       m_textanzeige.select(index, index + suchstring.length() );
       
    // Suchstring und Position in Instanzvariablen speichern
    this.suchstring = suchstring;
    this.index = index;
  
  } // Ende von 'stringSuchen' 

} // Ende von Klasse 'CEditor' 


// die Dialogklasse f�r die Eingabe des Suchstrings
class CFrageDialog extends JDialog implements ActionListener {
  private JTextField eingabefeld;
  private JButton oK, abbruch;
  private String suchstring;

  // der Konstruktor
  CFrageDialog(JFrame f, String titel) {
    super(f,titel,true);  // Konstruktor der Basisklasse aufrufen
    setResizable(false);

    setLayout(new BorderLayout());

    // es werden 2 Panels angelegt. Das eine enth�lt das TextField,
    // das andere die Schaltfl�chen
    JPanel panel1 = new JPanel();
    JLabel label = new JLabel("Bitte Suchstring eingeben:");
    panel1.add(label);
    eingabefeld = new JTextField(40);
    panel1.add(eingabefeld);
    add("Center",panel1);

    JPanel panel2 = new JPanel();
    oK = new JButton("OK");
    abbruch = new JButton("Abbrechen");
    panel2.add(oK);
    panel2.add(abbruch);
    add("South",panel2);
        
    pack();   // Anordnung der Oberfl�chenelemente auf bevorzugte 
              // Gr��e initialisieren

    // die Mausbehandlung f�r die Schaltfl�chen  macht die Klasse 
    // selbst, also bei sich selber registrieren
    oK.addActionListener(this);
    abbruch.addActionListener(this);

    // Fenster schlie�en = Fenster verbergen
    setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
  }

  public void actionPerformed(ActionEvent e)  {
    String label;

    label = e.getActionCommand();

    if(label.equals("Abbrechen")) {
      suchstring = null;
      setVisible(false);
      return;
    }        

    if(label.equals("OK")) {
      suchstring = eingabefeld.getText(); 
      setVisible(false); 
      return;
    }
  } // Ende von 'ActionPerformed' 

  // Diese Funktion liefert den eingegebenen Suchstring zur�ck
  public String getString()  {       
    return suchstring;
  }
} // Ende von 'CFrageDialog' 


