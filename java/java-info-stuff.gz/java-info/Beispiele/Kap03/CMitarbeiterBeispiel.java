class CMitarbeiter {
  String m_name;
  String m_vorname;
  int m_gehalt;       

  CMitarbeiter(String name, String vorname, 
               int gehalt) {
    m_name = name;
    m_vorname = vorname;
    m_gehalt = gehalt;
  }

  void datenAusgeben() {
    System.out.println("\n");
    System.out.println(" Name    : " + m_name);
    System.out.println(" Vorname : " + m_vorname);
    System.out.println(" Gehalt  : " + m_gehalt + " Euro");
  }

  void gehaltErhoehen(int erhoehung) {
    m_gehalt += erhoehung;
  }
} 

public class CMitarbeiterBeispiel {
  public static void main(String[] args) {
    // 2 neue Mitarbeiter instanziieren
    CMitarbeiter billy  = new CMitarbeiter("Gates","Bill",3000);
    CMitarbeiter stevie = new CMitarbeiter("Jobs","Steve",3500);

    // Daten ausgeben
    billy.datenAusgeben();
    stevie.datenAusgeben();

    // Gehalt von a erh�hen
    billy.gehaltErhoehen(500);

    // Kontrolle
    billy.datenAusgeben();
    stevie.datenAusgeben();
  }
}
