// Ein Funktionenplotter
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Hauptfenster von Swing-Klasse JFrame ableiten
public class CFunkPlotter2 extends JFrame {
  CMeineCanvas m_malflaeche;
  int aktFunktion = 0;    // diese Variable bestimmt die 
                          // zu zeichnende Funktion;
                          // Startwert 0 = keine Funktion

  public static void main(String[] args) {
    CFunkPlotter2 fenster = new CFunkPlotter2("Funktionenplotter");
    fenster.pack();
    fenster.setSize(450,350);
    fenster.setResizable(false);
    fenster.setVisible(true);
  }

  // Im Konstruktor werden die Canvas-Malfl�che und 
  // Schaltfl�chen zur Auswahl der Funktionen angelegt
  CFunkPlotter2(String titel) {
    super(titel);

    // Einen Layout-Manager einrichten
    setLayout(new FlowLayout());

    // Die Malfl�che aufnehmen
    m_malflaeche = new CMeineCanvas();
    add(m_malflaeche);
 
    // Panel-Container f�r Schaltfl�chen anlegen
    JPanel panel = new JPanel();
      // Gitter mit 2 Zeilen, 1 Spalte
      panel.setLayout(new GridLayout(2,1, 20, 20));     
  
      // Schaltfl�chen anlegen und in Panel aufnehmen
      JButton f1 = new JButton("tan(x)");
      JButton f2 = new JButton("x^3");
      panel.add(f1);
      panel.add(f2);
  
    add(panel);

    // Die Ereignisbehandlung f�r die Schaltfl�chen
    class CMeinActionLauscher implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        String label;

        label = e.getActionCommand();
       
        if(label.equals("tan(x)"))
            aktFunktion = 1;
        else
	      aktFunktion = 2;
         
        // Neuzeichnen veranlassen
        m_malflaeche.repaint();
      }
    }

    // Die Lausch-Objekte anlegen
    f1.addActionListener(new CMeinActionLauscher());
    f2.addActionListener(new CMeinActionLauscher());

    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 
  }

  class CMeineCanvas extends Canvas {
    // Konstruktor
    CMeineCanvas() {
      // den Hintergrund auf schwarz setzen
      setBackground(Color.black);

      // Vordergrund (=Zeichenfarbe) auf blau setzen
      setForeground(Color.green);
    }

    // Die wichtigste Methode: hier wird gezeichnet!
    public void paint(Graphics g) {
      double x,y;
      int xpos,ypos;

      // Ursprung umsetzen
      g.translate(150,150);
 
      // Koordinatenachsen einzeichnen
      g.setColor(Color.red);
      g.drawLine(0,-150,0,150);
      g.drawLine(-150,0,150,0);
      g.drawString("-3",-150,12);
      g.drawString("-3",4,147);
      g.drawString("+3",135,12);
      g.drawString("+3",4,-140);

      // Farbe zum Zeichnen der Funktion
      g.setColor(new Color(255,255,0));
        
      // Wenn keine Funktion ausgew�hlt ist, nichts tun
      if(aktFunktion == 0)
	  return;

      for(x= -3.0; x<=3; x += 0.005) {
        if(aktFunktion == 1)
          y = Math.tan(x);
        else
          y = Math.pow(x,3);

        xpos = (int) (x*50); 
        ypos = (int) (-y*50); 
       
        g.fillOval(xpos,ypos,3,3);
      }  
    }

    // Diese Methode liefert die minimale Gr��e der Canvas
    public Dimension getMinimumSize() {
      return new Dimension(300,300);
    }

    // Die Lieblingsgr��e setzen wir auf die Minimalgr��e
    public Dimension getPreferredSize() {
      return getMinimumSize();
    }
  }

} // Ende der Klasse CFunkPlotter
