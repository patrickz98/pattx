import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


class CMeinSchalter extends JButton {
  public CMeinSchalter(String titel) {
    super(titel);
  }

  public Dimension getMinimumSize() {
    return new Dimension(100,100);
  }
  public Dimension getPreferredSize() {
    return getMinimumSize();
  }
}
  

public class CEigenerSchalter extends JFrame {

  CEigenerSchalter(String titel) {
    super(titel);
    setLayout(new FlowLayout());
 
    CMeinSchalter schalter = new CMeinSchalter("Klick mich");
    add(schalter);
 
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
  }


  public static void main(String[] args) {
    CEigenerSchalter fenster = new CEigenerSchalter("Schaltfl�chen");
    fenster.pack();
    fenster.setVisible(true);   
  }
}
