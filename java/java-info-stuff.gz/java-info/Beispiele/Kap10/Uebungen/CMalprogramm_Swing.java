import java.awt.*;
import java.awt.event.*;

public class CMalprogramm_Swing extends Frame {
  CMeineCanvas m_malfl�che;            // Hier wird gezeichnet
  CheckboxGroup  m_formauswahl;        // liefert die zur Zeit ausgew�hlte Form
  int m_Ypos, m_Xpos;  

  // In main wird eine Instanz der Klasse angelegt und auf den Bildschirm
  // gebracht
  public static void main(String[] args) {
    CMalprogramm_Swing fenster = new CMalprogramm_Swing("Freihandlinien");
    fenster.pack();
    fenster.setSize(400,350);
    fenster.setResizable(false);
    fenster.setVisible(true);
  }

  // Im Konstruktor wird eine Canvas-Malfl�che angelegt sowie  
  // eine ButtonGroup-Gruppe mit 
  // zur Auswahl stehenden Zeichenformen
  CMalprogramm_Swing(String titel) {
    super(titel);

    // Einen Layout-Manager anlegen
    setLayout(new FlowLayout());

    // Die Malfl�che anlegen
    m_malfl�che = new CMeineCanvas();
    add(m_malfl�che);

    // Panel-Container f�r Schaltfl�chen anlegen
    Panel panel = new Panel();
      // Gitter mit 3 Zeilen, 1 Spalte
      panel.setLayout(new GridLayout(4,1,20,20));     

      // Optionsfelder zur Auswahl der Formen anlegen
      m_formauswahl = new CheckboxGroup();

      // 1. Optionsfelder erzeugen
      Checkbox opt1 = new Checkbox ("Kreis",false, m_formauswahl);
      Checkbox opt2 = new Checkbox ("Scheibe",false, m_formauswahl);
      Checkbox opt3 = new Checkbox ("Rechteck",false, m_formauswahl); 
      Checkbox opt4 = new Checkbox ("Freihand",false, m_formauswahl); 

      // 3. Optionsfelder in Panel aufnehmen
      panel.add(opt1);
      panel.add(opt2);
      panel.add(opt3);
      panel.add(opt4);
     
    add(panel);
  
  
    // Event-Handling zum Schlie�en des Fensters implementieren
    // als innere Klasse
    class CMeinWindowAdapter extends WindowAdapter  {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    }

    // Das Lausch-Objekt anlegen und die Instanz der Klasse bei ihm 
    // anmelden
    addWindowListener(new CMeinWindowAdapter());
  }


  class CMeineCanvas extends Canvas {
    // Die Adapter-Klasse f�r die Mausklicks  als innere Klasse
    // von Meine_Canvas 
    class CMeinMausAdapter extends MouseAdapter {
      public void mousePressed(MouseEvent e) {
         // Die aktuelle Position der Maus merken
         m_Xpos = e.getX();
         m_Ypos = e.getY();

         // Malfl�che aktualisieren
         repaint();
      }
    }

    class CMeinMausMotionAdapter extends MouseMotionAdapter {
      public void mouseDragged(MouseEvent e) {
        Checkbox aktuell;
        String label;

        // Herausfinden, welche Box gerade aktiviert ist
        aktuell = m_formauswahl.getSelectedCheckbox();

        // Da nach dem Programmstart keine Box aktiviert ist, mu�    
        // dies getestet werden. Dann wird kein Objekt zur�ckgeben, 
        // sondern ein null-Wert
        if(aktuell == null)
          return;

        label = aktuell.getLabel();

        // Nur wenn die Freihandfunktion ausgew�hlt ist, die
        // Mausposition merken und neuzeichnen
        if(label.equals("Freihand")) {
          Graphics tmp = m_malfl�che.getGraphics();
          m_Xpos = e.getX();
          m_Ypos = e.getY();
          tmp.drawOval(m_Xpos,m_Ypos,2,2);
        }
      }
    }
  
    // der Konstruktor implementiert die Mausbehandlung und setzt
    // Hintergrund und Vordergrund (=Zeichen)farbe
    CMeineCanvas() {
      addMouseListener(new CMeinMausAdapter());
      addMouseMotionListener(new CMeinMausMotionAdapter());

      setBackground(Color.black);
      setForeground(Color.orange);
    }

    // Die wichtigste Methode: hier wird gezeichnet!
    public void paint(Graphics g) {
      String label;
      Checkbox aktuell = null;

      // welche Form ist gerade ausgew�hlt?
      aktuell = m_formauswahl.getSelectedCheckbox();

      // entsprechend handeln
      if(aktuell == null)
        return;

      int w = (int) (Math.random()*300);
      int h = (int) (Math.random()*300);
     label = aktuell.getLabel();

      if(label.equals("Kreis"))
        g.drawOval(m_Xpos,m_Ypos,w,h);

      if(label.equals("Scheibe"))
        g.fillOval(m_Xpos,m_Ypos,w,h);

      if(label.equals("Rechteck"))
        g.drawRect(m_Xpos,m_Ypos,w,h);
    }

    // Diese Methode liefert die minimale Gr��e der Canvas
    public Dimension getMinimumSize() {
      return new Dimension(300,300);
    }

    // Die Lieblingsgr��e setzen wir auf die Minimalgr��e
    public Dimension getPreferredSize() {
      return getMinimumSize();
    }
  }  // Ende von CMeineCanvas

} 
