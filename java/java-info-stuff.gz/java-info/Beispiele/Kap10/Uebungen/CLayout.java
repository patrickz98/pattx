import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CLayout extends JFrame {

  CLayout(String titel) {
    super(titel);
    setLayout(new BorderLayout());
    
    Panel p = new Panel();
    JButton schalter1 = new JButton("Klick mich");
    JButton schalter2 = new JButton("Klick mich");
    schalter2.setFont(new Font(Font.SERIF, Font.BOLD, 14));
    p.add(schalter1);
    p.add(schalter2);
 
    JButton schalter3 = new JButton("Richtig, mich solltest du klicken");
    add(p,"North");
    add(new JLabel("H�r nicht auf die beiden!",SwingConstants.CENTER),"Center");
    add(schalter3,"South");

    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
  }

  public static void main(String[] args) {
    CLayout fenster = new CLayout("Layout");
    fenster.pack();
    fenster.setVisible(true);   
  }
}
