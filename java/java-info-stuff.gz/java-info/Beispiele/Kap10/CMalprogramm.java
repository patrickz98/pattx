// Ein Malprogramm
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CMalprogramm extends JFrame {
  CMeineCanvas m_malfl�che;     // Hier wird gezeichnet
  ButtonGroup  m_formauswahl;   // aktuelle Form
  int m_Xpos, m_Ypos;           // aktuelle Mausposition

  // In main() wird eine Instanz der Klasse angelegt 
  // und auf den Bildschirm gebracht 
  public static void main(String[] args) {
    CMalprogramm fenster = new CMalprogramm("Malprogramm");
    fenster.pack();
    fenster.setSize(400,350);
    fenster.setResizable(false);
    fenster.setVisible(true);
  }

  // Im Konstruktor wird eine Canvas-Malfl�che   
  // angelegt sowie eine ButtonGroup-Gruppe mit 
  // zur Auswahl stehenden Zeichenformen
  CMalprogramm(String titel) {
    super(titel);

    // Einen Layout-Manager anlegen
    setLayout(new FlowLayout());

    // Die Malfl�che anlegen
    m_malfl�che = new CMeineCanvas();
    add(m_malfl�che);

    // Panel-Container f�r Schaltfl�chen anlegen
    JPanel panel = new JPanel();
      // Gitter mit 3 Zeilen, 1 Spalte
      panel.setLayout(new GridLayout(3,1,20,20));     

      // Optionsfelder zur Auswahl der Formen 
      m_formauswahl = new ButtonGroup();

      // 1. Optionsfelder erzeugen
      JRadioButton opt1 = new JRadioButton("Kreis",false);
      JRadioButton opt2 = new JRadioButton("Scheibe",false);
      JRadioButton opt3 = new JRadioButton("Rechteck",false); 

      // 2. Befehlsnamen f�r Optionsfelder 
      opt1.setActionCommand("Kreis");
      opt2.setActionCommand("Scheibe");
      opt3.setActionCommand("Rechteck");

      // 3. Optionsfelder in ButtonGroup-Gruppe 
      //    aufnehmen
      m_formauswahl.add(opt1);
      m_formauswahl.add(opt2);
      m_formauswahl.add(opt3);

      // 4. Optionsfelder in Panel aufnehmen
      panel.add(opt1);
      panel.add(opt2);
      panel.add(opt3);
     
     add(panel);
     setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);   
  }


  class CMeineCanvas extends Canvas {
    // Die Adapter-Klasse f�r die Mausklicks  als 
    // innere Klasse von CMeineCanvas 
    class CMeinMausAdapter extends MouseAdapter {
      public void mousePressed(MouseEvent e) {
        // Die aktuelle Position der Maus merken
        m_Xpos = e.getX();
        m_Ypos = e.getY();

        // Malfl�che aktualisieren
        repaint();
      }
    }

    // der Konstruktor implementiert die Mausbehandlung 
    // und setzt Hintergrund und Vordergrundfarbe
    CMeineCanvas() {
      addMouseListener(new CMeinMausAdapter());

      setBackground(Color.black);
      setForeground(Color.orange);
    }

    // Die wichtigste Methode: hier wird gezeichnet!
    public void paint(Graphics g) {
      String label;
      ButtonModel aktuell = null;

      // welche Form ist gerade ausgew�hlt?
      aktuell = m_formauswahl.getSelection();

      // entsprechend handeln
      if(aktuell == null)
        return;

      int w = (int) (Math.random()*300);
      int h = (int) (Math.random()*300);
      label = aktuell.getActionCommand();

      if(label.equals("Kreis"))
        g.drawOval(m_Xpos,m_Ypos,w,w);

      if(label.equals("Scheibe"))
        g.fillOval(m_Xpos,m_Ypos,w,h);

      if(label.equals("Rechteck"))
        g.drawRect(m_Xpos,m_Ypos,w,h);
    }

    // Diese Methode liefert die minimale Gr��e der Canvas
    public Dimension getMinimumSize() {
      return new Dimension(300,300);
    }

    // Die Lieblingsgr��e setzen wir auf die Minimalgr��e
    public Dimension getPreferredSize() {
      return getMinimumSize();
    }
  }  // Ende von CMeineCanvas 

} // Ende von CMalprogramm 
