// Datei CKopierenSchnell.java
import java.io.*;

public class CKopierenSchnell {
  public static void main(String[] args) {
    try {
      String zeile;
      BufferedReader ein = new BufferedReader(new FileReader("john_maynard.txt"));
      BufferedWriter aus = new BufferedWriter(new FileWriter("kopie.txt"));

      while((zeile = ein.readLine()) != null) {
          aus.write(zeile,0, zeile.length());
	    aus.newLine(); 
      }

      ein.close();
      aus.close();
    }
    catch (IOException e) {
       System.err.println(" Fehler mit Datei: " + e.getMessage());
    }
  }
}
