import java.io.PrintWriter;

public class CDateiSchreiben {
  public static void main(String[] args) {
    // Datei Ein- und Ausgabe mu� durch try-catch gesichert werden 
    try {
      PrintWriter ausgabe = new PrintWriter("Test.txt");

      String ware  = "Heft";
      double preis = 1.75;
      ausgabe.printf(" 1 %10s kostet %.2f Euro %n", ware, preis);
	
      ware  = "F�ller";
      preis = 0.55;
      ausgabe.printf(" 1 %10s kostet %.2f Euro %n", ware, preis);
	  
      ausgabe.close();
    }
    catch(Exception e) {
      System.err.println(e); 
    }
  }
}
