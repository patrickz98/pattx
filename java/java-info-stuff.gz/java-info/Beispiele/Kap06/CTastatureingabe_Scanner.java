import java.util.*;
import java.io.Console;

public class CTastatureingabe_Scanner {
    
   public static void main(String[] args) {
      Console cons = System.console();
      Scanner sc = new Scanner(System.console().reader());      
      cons.printf("\n");

      try {      
        cons.printf(" Geben Sie Ihren Nachnamen ein: ");
        String name = sc.nextLine();

        cons.printf(" Geben Sie Ihr Alter ein      : ");
        int alter = sc.nextInt();

        cons.printf("\n");
        cons.printf(" %d Jahre?", alter);
        cons.printf(" Haben Sie da auch nicht geflunkert,"
                  + " Herr oder Frau %s?\n", name);
      }
      catch (InputMismatchException e) {
        System.err.println("\n Fehler! \n" + 
                           " Zahleneingabe kann nicht eingelesen werden.");
      }
   }    
}
