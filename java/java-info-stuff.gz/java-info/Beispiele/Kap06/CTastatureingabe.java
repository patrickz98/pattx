import java.util.Scanner;
import java.io.Console;

public class CTastatureingabe {
    
   public static void main(String[] args) {
      Console cons = System.console();
      cons.printf("\n");

      try {      
        cons.printf(" Geben Sie Ihren Nachnamen ein: ");
        String name = cons.readLine();

        cons.printf(" Geben Sie Ihr Alter ein      : ");
        String eingabe = cons.readLine();
        int alter = Integer.parseInt(eingabe);

        cons.printf("\n");
        cons.printf(" %d Jahre?", alter);
        cons.printf(" Haben Sie da auch nicht geflunkert,"
                  + " Herr oder Frau %s?\n", name);
      }
      catch (NumberFormatException e) {
        System.err.println("\n Fehler! \n" + 
                           " Zahleneingabe kann nicht eingelesen werden.");
      }
   }    
}
