import java.io.PrintWriter;

public class CPrintWriterDemo {
  public static void main(String[] args) {
    PrintWriter ausgabe = new PrintWriter(System.console().writer(), true);
    //PrintWriter ausgabe = new PrintWriter(System.out);

    ausgabe.println();

    String ware  = "Heft";
    double preis = 1.75;
    ausgabe.printf(" 1 %10s kostet %.2f Euro \n", ware, preis);
	
    ware  = "F�ller";
    preis = 0.55;
    ausgabe.printf(" 1 %10s kostet %.2f Euro \n", ware, preis);

    ausgabe.close();
  }
}
