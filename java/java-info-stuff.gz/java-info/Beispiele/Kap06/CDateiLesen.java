import java.io.*;

public class CDateiLesen {
  public static void main(String[] args) throws IOException {
   FileReader eingabestream = new FileReader("john_maynard.txt");
   StringBuilder text = new StringBuilder(10);
   int gelesen;
   boolean ende = false;

   // lese Zeichen, bis Dateiende erreicht ist
   while(!ende) {
      gelesen = eingabestream.read();

      if(gelesen == -1)
        ende = true;
      else
        text.append( (char) gelesen);
   }
   System.console().printf("\n");
   System.console().printf(text.toString());
  }
}
