// Datei CDateiListe.java
// Gibt den Inhalt eines Verzeichnisses aus
 import java.io.*;
 
 public class CDateiListe  {
    public static void main(String[] args)  {
   
      if(args.length != 1) {
	    System.out.println(" Verzeichnis angeben!");
	    System.exit(0); 
      }
       
      try {
        File wurzel = new File(args[0]); 

        if(wurzel.isDirectory() == true) {
	    File[] inhalt = wurzel.listFiles();

	    for(int i = 0; i < inhalt.length; i++)
             System.out.println(inhalt[i].getCanonicalPath()); 
        }
      }
      catch(Exception e) {
	    System.err.println(e); 
      }
   }
 }

