import java.util.Scanner;

public class CFrage {
  public static void main(String[] args) {
    Scanner ein = new Scanner(System.console().reader()); 
    String zeile = ein.nextLine();
    System.console().printf(zeile.toUpperCase());
  }
}