import java.io.*;

public class CKopieren {
  public static void main(String[] args) {
    try {
      int zeichen;
      FileReader ein = new FileReader("john_maynard.txt");
      FileWriter aus = new FileWriter("kopie.txt");

      while((zeichen = ein.read()) != -1)  {
          aus.write(zeichen);
      }

      ein.close();
      aus.close();
    }
    catch (IOException e) {
       System.err.println(" Fehler mit Datei: " + 
                          e.getMessage());
    }
  }
}