import java.io.*;

public class CGenmanipulation {
  public static void main(String[] args) throws IOException {
    Console cons = System.console();
    cons.printf("\n");

    StringBuilder gencode = new StringBuilder(
                 "GUG-CAU-CUU-ACG-CCC-GUG-GAG-AAG");

    cons.printf(" Vor der Operation \n");
    cons.printf(" Genetischer Code = %s \n", gencode);

    // Eingriff: Zeichen an Position 21 �ndern
    gencode.setCharAt(21,'A');

    cons.printf("\n");
    cons.printf(" Nach der Operation \n");
    cons.printf(" Genetischer Code = %s \n", gencode);
  }
}