import java.io.Console;

public class CBildschirmausgabe {
  public static void main(String[] args) {
    Console cons = System.console();
    cons.printf("\n");
    
    String ware  = "Heft";
    double preis = 1.75;
    cons.printf(" 1 %10s kostet %.2f Euro \n", ware, preis);

    ware = "F�ller";
    preis = 0.55;
    cons.printf(" 1 %10s kostet %.2f Euro \n", ware, preis);  
  }
}
