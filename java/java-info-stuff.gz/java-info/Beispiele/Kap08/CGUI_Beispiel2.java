// Das erste GUI-Programm mit Ereignisbehandlung
import java.awt.*;
import java.awt.event.*;

public class CGUI_Beispiel2 extends Frame {
  // Die eigenen Adapter- und Listener-Klassen als 
  // innere Klassen innerhalb der Klasse 
  // CGUI_Beispiel2  definieren
  class CMeinWindowLauscher extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
      // Das Programm beenden
      System.exit(0);
    }
  }
 
  class CMeinActionLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      // einmal piepen
      java.awt.Toolkit.getDefaultToolkit().beep();
    }
  }

  // der Konstruktor legt drei Schaltfl�chen an
  CGUI_Beispiel2(String titel) {
    super(titel);

    // Schaltfl�chen erzeugen
    Button h�nsel = new Button("H�nsel");
    Button und  = new Button("und");
    Button gretel = new Button("Gretel");


    // Einen Layout-Manager zum Anordnen der Schalter festlegen
    setLayout(new FlowLayout());

    // Schaltfl�chen zum Frame hinzuf�gen
    add(h�nsel);
    add(und);
    add(gretel);

    // den Frame bei einem WindowListener anmelden
    addWindowListener(new CMeinWindowLauscher());

    // ActionListener f�r die Schaltfl�chen registrieren
    // Es wird jedes Mal eine neue Instanz angelegt. Man 
    // kann aber auch eine Instanz mehrfach verwenden
    h�nsel.addActionListener(new CMeinActionLauscher());
    und.addActionListener(new CMeinActionLauscher());
    gretel.addActionListener(new CMeinActionLauscher());
  }

  public static void main(String[] args) {
    // eine Instanz der Klasse anlegen und anzeigen
    CGUI_Beispiel2 fenster = new CGUI_Beispiel2("GUI mit Ereignisbehandlung");
    fenster.pack();
    fenster.setVisible(true);   
  }
}
