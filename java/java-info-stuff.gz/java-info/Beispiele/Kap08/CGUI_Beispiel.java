import java.awt.*;

public class CGUI_Beispiel extends Frame{
  // der Konstruktor legt drei Schaltfl�chen an
  CGUI_Beispiel(String titel) {
    super(titel);                      // Fenstertitel

    // Schaltfl�chen erzeugen
    Button h�nsel = new Button("H�nsel");
    Button und    = new Button("und");
    Button gretel = new Button("Gretel");

    // Einen Layout-Manager zum Anordnen der Schalter festlegen
    setLayout(new FlowLayout());

    // zum Frame hinzuf�gen
    add(h�nsel);
    add(und);
    add(gretel);
  }

  public static void main(String[] args) {
    // eine Instanz der Fensterklasse anlegen
    CGUI_Beispiel fenster = 
                     new CGUI_Beispiel("Erstes GUI-Programm");

    fenster.pack();
    fenster.setVisible(true);
  }
}