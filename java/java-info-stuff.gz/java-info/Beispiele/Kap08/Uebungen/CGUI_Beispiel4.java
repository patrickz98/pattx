// Das erste GUI-Programm mit Ereignisbehandlung
import java.awt.*;
import java.awt.event.*;

public class CGUI_Beispiel4 extends Frame {
  Button m_h�nsel, m_und, m_gretel;

  // Die eigenen Adapter- und ListenerKlassen als 
  // innere Klassen innerhalb der Klasse 
  // CGUI_Beispiel4 definieren
  class CMeinWindowLauscher extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
      // Das Programm beenden
      System.exit(0);
    }
  }
 
class CMeinMouseLauscher implements MouseListener{
   public void mouseClicked(MouseEvent e){
      // einmal piepen
      java.awt.Toolkit.getDefaultToolkit().beep();
   }
   public void mouseEntered(MouseEvent e) {
   }
   public void mouseExited(MouseEvent e) {
   }
   public void mousePressed(MouseEvent e) {
   }
   public void mouseReleased(MouseEvent e) {
   }
}

  // der Konstruktor legt drei Schaltfl�chen an
  CGUI_Beispiel4(String titel) {
    super(titel);

    // Schaltfl�chen erzeugen
    m_h�nsel = new Button("H�nsel");
    m_und  = new Button("und");
    m_gretel = new Button("Gretel");


    // Einen Layout-Manager zum Anordnen der Schalter festlegen
    setLayout(new FlowLayout());

    // Schaltfl�chen zum Frame hinzuf�gen
    add(m_h�nsel);
    add(m_und);
    add(m_gretel);

    // den Frame bei einem WindowListener anmelden
    addWindowListener(new CMeinWindowLauscher());

    // ActionListener f�r die Schaltfl�chen registrieren
    // Es wird jedes Mal eine neue Instanz angelegt. Man 
    // kann aber auch eine Instanz mehrfach verwenden
    m_h�nsel.addMouseListener(new CMeinMouseLauscher());
    m_und.addMouseListener(new CMeinMouseLauscher());
    m_gretel.addMouseListener(new CMeinMouseLauscher());
  }

  public static void main(String[] args) {
    // eine Instanz der Klasse anlegen und anzeigen
    CGUI_Beispiel4 fenster = new CGUI_Beispiel4("GUI mit Ereignisbehandlung");
    fenster.pack();
    fenster.setVisible(true);   
  }
}
