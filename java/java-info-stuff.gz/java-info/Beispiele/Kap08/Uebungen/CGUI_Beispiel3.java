// Das erste GUI-Programm mit Ereignisbehandlung
import java.awt.*;
import java.awt.event.*;

public class CGUI_Beispiel3 extends Frame {
  Button m_h�nsel, m_und, m_gretel;

  // Die eigenen Adapter- und Listener-Klassen als 
  // innere Klassen innerhalb der Klasse 
  // CGUI_Beispiel3 definieren
  class CMeinWindowLauscher extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
      // Das Programm beenden
      System.exit(0);
    }
  }
 
  class CMeinActionLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      // Titel �ndern
      m_h�nsel.setLabel("verirrten");      
      m_und.setLabel("sich");      
      m_gretel.setLabel("im Wald");      
    }
  }

  // der Konstruktor legt drei Schaltfl�chen an
  CGUI_Beispiel3(String titel) {
    super(titel);

    // Schaltfl�chen erzeugen
    m_h�nsel = new Button("H�nsel");
    m_und  = new Button("und");
    m_gretel = new Button("Gretel");


    // Einen Layout-Manager zum Anordnen der Schalter festlegen
    setLayout(new FlowLayout());

    // Schaltfl�chen zum Frame hinzuf�gen
    add(m_h�nsel);
    add(m_und);
    add(m_gretel);

    // den Frame bei einem WindowListener anmelden
    addWindowListener(new CMeinWindowLauscher());

    // ActionListener f�r die Schaltfl�chen registrieren
    // Es wird jedes Mal eine neue Instanz angelegt. Man 
    // kann aber auch eine Instanz mehrfach verwenden
    m_h�nsel.addActionListener(new CMeinActionLauscher());
    m_und.addActionListener(new CMeinActionLauscher());
    m_gretel.addActionListener(new CMeinActionLauscher());
  }

  public static void main(String[] args) {
    // eine Instanz der Klasse anlegen und anzeigen
    CGUI_Beispiel3 fenster = new CGUI_Beispiel3("GUI mit Ereignisbehandlung");
    fenster.pack();
    fenster.setVisible(true);   
  }
}
