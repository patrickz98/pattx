// sich bewegende Bohnen!
import java.awt.*;
import java.net.*;
import java.applet.*;
import java.awt.event.*;

public class CBohnen_Applet extends Applet
                            implements Runnable {
  Thread       m_bohne;
  AudioClip    m_klang;      // die Hintergrund-Musik
  MediaTracker m_tracker;    // �berwacht Laden der Bilder
  Image[]      m_bilderfeld = new Image[11];   // die Bilder
  int          m_aktBild ;  // Index des Bildes, das gerade
                            // angezeigt werden soll
  int m_bildH�he;       
  int m_bildBreite;


  public void init() {
    URL Codebase;

    // Hintergrundfarbe hellgrau
    setBackground(Color.lightGray);

    Codebase = getCodeBase();
    m_tracker = new MediaTracker(this);

    // die Sounddatei laden
    m_klang = getAudioClip(Codebase,"spacemusic.au");

    // die  Einzelbilder laden, die zur Animation der
    // Bohnen dienen; werden in Array gespeichert

    for(int i=1; i<= 10; i++)  {
      m_bilderfeld[i]= getImage(Codebase,"T"+i+".gif");

      // alle Bilder bei MediaTracker angemelden
      m_tracker.addImage(m_bilderfeld[i],1);
    }

    // das Laden abschlie�en
    try  {
       m_tracker.waitForAll();
       m_aktBild = 1;
    }
    catch(InterruptedException e) {
       return;
    }
  }
  

  public void start() {
    // den  Thread starten
    if(m_bohne == null) {
      m_bohne = new Thread(this);
      m_bohne.start();

      // den Sound als Endlosschleife starten
      if(m_klang != null)
         m_klang.loop();
    }
  }

  public void stop() {
    // den Thread beenden
    if(m_bohne != null) {
      m_bohne = null;
    }

    // den Klang stoppen
    if(m_klang != null)
        m_klang.stop();
  }

  public void destroy() {
    // den Thread beenden
    if(m_bohne != null) {
      m_bohne = null;
    }

    // den Klang stoppen
    if(m_klang != null)
        m_klang.stop();
  }

  // Die run-Methode des Threads steht innerhalb
  // des Applets!
  public void run()  {
    while(m_bohne == Thread.currentThread())  {
      // die Ma�e des alten Bildes merken, damit in
      // paint() der entsprechende Ausschnitt
      // gel�scht werden kann
      m_bildBreite = m_bilderfeld[m_aktBild].getWidth(this);
      m_bildH�he =   m_bilderfeld[m_aktBild].getHeight(this);

      m_aktBild++;       // das Bild wechseln
      if(m_aktBild > 10)
        m_aktBild = 1;

      repaint();         // ... und anzeigen
      try {
        m_bohne.sleep(200);
         if(m_aktBild == 10)
             m_bohne.sleep(500);
      }
      catch(InterruptedException e)  {
        return;
      }                                                                            
    }
  }

  // update �berschreiben, damit kein unn�tiges
  // L�schen vor dem Aufruf von paint() erfolgt
  public void update(Graphics g) {
    paint(g);
  }

  // hier wird das aktuelle Bild angezeigt
  public void paint(Graphics g) {
    // wenn Bilder noch nicht geladen, nichts tun
    if(!m_tracker.checkAll())
        return;

    // letztes Bild l�schen
    g.setColor(Color.lightGray);
    g.fillRect(0,0,m_bildBreite,m_bildH�he);

    // das aktuelle Bild anzeigen
    g.drawImage(m_bilderfeld[m_aktBild], 0, 0,this);
  }
} // Ende der Klasse 'CBohnen_Applet' 
