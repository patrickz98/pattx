//Java-Anwendung mit Datenbankzugriff
import java.sql.*;
import java.io.*;

public class CDatenbank {
  public static void main (String args[])  {
    String URL          = "jdbc:odbc:L�nder";
    String benutzername = "Mickey";
    String passwort     = "Mouse";

    // Treiber laden 
    try  {
       Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    } 
    catch (Exception e)  {
       System.err.println(" JDBC/ODBC-Treiber konnte nicht geladen werden.");
       return;
    }

    // Verbindung zu Datenbank aufbauen
    Statement  befehl     = null;
    Connection verbindung = null;
    try  {
       verbindung = DriverManager.getConnection (
                      URL,
                      benutzername,
                      passwort);
       befehl = verbindung.createStatement();
    } 
    catch (Exception e)  {
       System.err.println(" Verbindung zu " + URL 
                          + " konnte nicht hergestellt werden");
    }

    // Daten auslesen
    try {
       ResultSet datenmenge;
       datenmenge = befehl.executeQuery("SELECT * FROM Bundesl�nder ORDER BY Bundesland;");

       // Ueberschriften ausgeben
       Console cons = System.console();
       cons.printf("\n");
       cons.printf("  Bundesland \t   Einwohner (in Mio) \n");
       cons.printf("\n");

       // Einzelne Datenseatze ausgeben
       String land;
       int    einw;

       while(datenmenge.next())  {
         land = datenmenge.getString("Bundesland");
         einw = datenmenge.getInt("Einw (in Mio)");
         cons.printf("  %s \t\t %d \n", land, einw);
       }
  
       verbindung.close();
    }
    catch (Exception e) {
       e.printStackTrace();
    }
  }
}
