class CDummy {
   int wert;
}

class CBeispiel  {
  int wert;

  int machWas(double para1, CDummy para2) {
    para1 = 0;
    para2.wert = 50;

    return 0;
  }
}


public class CParameter {
  public static void main(String[] args) {
    System.out.println();

    CBeispiel hugo = new CBeispiel();
    CDummy uebergabe = new CDummy();
    int ergebnis;
    double wert = 10.5;

    uebergabe.wert = 100;
    System.out.println(" Parameter vor  Aufruf: \t" 
                   + wert + "\t" + uebergabe.wert);
    ergebnis = hugo.machWas(wert,uebergabe);
    System.out.println(" Parameter nach Aufruf: \t"
                   + wert + "\t" + uebergabe.wert);
  }
}