class CThis  {
  public static void main(String[] args) {
    System.out.println();

    CDemo_this inst = new CDemo_this();
    System.out.println(" Instanz inst = " + inst);
    inst.this_wert();
  }
}

class CDemo_this {
  void this_wert() {
    System.out.println(" this hat den Wert : " + this);
  }
}
