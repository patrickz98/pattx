class CIchZaehlMich {
  int        m_instanzvariable = 0;
  static int m_klassenvariable = 0;

  CIchZaehlMich() {
    m_instanzvariable++;
    m_klassenvariable++;
    System.out.print(" Inst.variable = " + m_instanzvariable);
    System.out.println("\t Klas.variable = " + m_klassenvariable);
  }
 
  protected void finalize() {
    m_klassenvariable--;
    System.out.println(" Klas.variable = " +  m_klassenvariable);
  }
}

public class CInstanzenzaehler  {
  static void erzeugeInstanzen() {
    CIchZaehlMich instanz_1 = new CIchZaehlMich(); 
    CIchZaehlMich instanz_2 = new CIchZaehlMich(); 
    CIchZaehlMich instanz_3 = new CIchZaehlMich(); 
  }

  public static void main(String[] args) 
                        throws InterruptedException  {
    System.out.println("\n Instanzen erzeugen: \n");
    erzeugeInstanzen();

    System.out.println("\n Instanzen aufloesen: \n");
    System.gc();
    System.runFinalization();   
  }
}