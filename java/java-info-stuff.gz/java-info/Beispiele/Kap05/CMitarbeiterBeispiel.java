class CMitarbeiter {
  String m_name;
  String m_vorname;
  int m_gehalt;       

  CMitarbeiter(String name, String vorname, int gehalt) {
    m_name = name;
    m_vorname = vorname;
    m_gehalt = gehalt;
  }

  void datenAusgeben() {
    System.out.println("\n");
    System.out.println(" Name    : " + m_name);
    System.out.println(" Vorname : " + m_vorname);
    System.out.println(" Gehalt  : " + m_gehalt + " Euro");
  }

  void gehaltErhoehen(int erhoehung) {
    m_gehalt += erhoehung;
  }
} 

// Die abgeleitete Klassen
class CLehrling extends CMitarbeiter {
  int abgelegtePruefungen;

  // Konstruktor setzt die Anzahl der Pr�fungen auf 0
  CLehrling(String name, String vorname, int gehalt)  {
    // den Konstruktor der Basisklasse aufrufen
    super(name, vorname, gehalt);

    // Initialisierung der eigenen Felder
    abgelegtePruefungen = 0;
  }
}

class CAngestellter extends CMitarbeiter {
  int hierarchiestufe;
  final int MAX_HIERARCHIE = 5;

  // Konstruktor
  CAngestellter(String name, String vorname, int gehalt) {
    // den Konstruktor der Basisklasse aufrufen
    super(name,vorname,gehalt);

    // Initialisierung der eigenen Felder
    hierarchiestufe = 0;
  }

  void befoerdern() {
     // falls noch m�glich, bef�rdern
     if(hierarchiestufe < MAX_HIERARCHIE)
        hierarchiestufe++;
  }
}

class CChef extends CMitarbeiter {
  // keine Erweiterungen

  // Konstruktor von Chef ruft nur den Konstruktor 
  // der Basisklasse auf
  CChef(String name, String vorname,int gehalt)  {
    super(name,vorname,gehalt);
  }

  // beim Gehalt erh�lt der Chef mehr
  void gehaltErhoehen(int erhoehung) {
    m_gehalt += 2*erhoehung;
  }
}


public class CMitarbeiterBeispiel {
  public static void main(String[] args) {

    CMitarbeiter[] personalListe = new CMitarbeiter[3];

    personalListe[0] = new CChef("Groucho","Marx",8000);
    personalListe[1] = new CAngestellter("Chico","Marx",4000);
    personalListe[2] = new CLehrling("Harpo","Marx",1000);

    // Daten ausgeben
    for (int i = 0; i < personalListe.length; i++)
      personalListe[i].datenAusgeben();

    // Gehalt erh�hen
    for (int i = 0; i < personalListe.length; i++)
      personalListe[i].gehaltErhoehen(1000);

    // Daten ausgeben
    for (int i = 0; i < personalListe.length; i++)
      personalListe[i].datenAusgeben();

  }
}

