// Die Basisklasse
abstract class CFigur {
  int m_xKoord, m_yKoord;  //xy.Koordinate der Figur

  CFigur(int x, int y) {
    m_xKoord = x;
    m_yKoord = y;
  }

  abstract void zeichnen();
}

// Abgeleitete Klasse
class CKreis extends CFigur {
  int m_radius;

  CKreis(int x, int y, int r) {
    super(x,y);
    m_radius = r;
  }
    
  void zeichnen() {
    System.out.println(" Zeichnen-Methode fuer Kreise");
  }
}

// Abgeleitete Klasse
class CRechteck extends CFigur {
  int m_breite, m_laenge;

  CRechteck(int x, int y, int l, int b) {
    super(x,y);
    m_laenge = l;
    m_breite = b;
  }
 
  void zeichnen() {
    System.out.println(" Zeichnen-Methode fuer Rechtecke");
  }
}

// Abgeleitete Klasse
class CLinie extends CFigur {
  int m_endpX, m_endpY;

  CLinie(int ax, int ay, int ex, int ey) {
    super(ax,ay);
    m_endpX = ex;
    m_endpY = ey;
    }

  void zeichnen() {
    System.out.println(" Zeichnen-Methode fuer Linien");
  }
}

public class CZeichnen {
  static CFigur[] zeichenobjekte = new CFigur[5];

  public static void main(String[] args) {
    System.out.println();
    
    zeichenobjekte[0] = new CKreis(20,30,10);
    zeichenobjekte[1] = new CRechteck(2,78,50,50);
    zeichenobjekte[2] = new CKreis(99,30,10);
    zeichenobjekte[3] = new CLinie(201,44,201,66);
    zeichenobjekte[4] = new CLinie(10,50,50,50);
 
    for(int loop=0;loop<zeichenobjekte.length;loop++) 
      zeichenobjekte[loop].zeichnen();
  }
}    

