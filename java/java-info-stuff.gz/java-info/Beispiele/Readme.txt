Linux-Anwender sollten die Quelldateien, die Umlaute enthalten, vor dem Kompilieren in UTF-8-Format umwandeln. 

Laden Sie die Quelldatei dazu in einen passenden Editor (z.B. KWrite) und speichern Sie die Datei dann unter gleichem Namen im UTF-8-Format. 

Wenn Sie keinen Editor finden, mit dem Sie das Format �ndern k�nnen, tippen Sie die Umlaute einfach erneut ein.