// Bildbetrachter
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class CBildbetrachter3 extends JFrame {
  static CBildbetrachter3 m_fenster;
  String m_dateiname;             // Name der Datei
  Image   m_aktBild;              // Referenz auf das aktuelle Bild
  CBildLeinwand m_bildanzeige;    // JPanel zum Anzeigen des Bildes
  int m_Xpos,m_Ypos;              // neue Position, an der die 
                                  // linke obere Ecke des Bildes 
                                  // angezeigt wird
  int m_bild_x1,m_bild_y1;        // die aktuelle Begrenzung 
  int m_bild_x2,m_bild_y2;        // des Bildes
  int m_bildHoehe,m_bildBreite;   // H�he und Breite in Pixeln

  // Ereignisbehandlung
  class CMeinActionLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      String Label;

      Label = e.getActionCommand();

      if(Label.equals("Programm beenden"))
         System.exit(0);

      if(Label.equals("Bild laden"))
         bildLaden();         
      }
    }

  // Im Konstruktor werden ein Panel (als Zeichenfl�che)
  // und eine Men�leiste angelegt
  CBildbetrachter3(String titel) {
    super(titel);

    m_Xpos = m_Ypos = 0;       // Startposition : links oben
    m_bild_x1 = m_bild_x2 = m_bild_y1 = m_bild_y2 = 0;

    // Zu Beginn ist kein Bild geladen
    m_dateiname = null;
    m_aktBild = null;

    // Einen Layout-Manager anlegen
    setLayout(new FlowLayout());

    // Eine Leinwand anlegen (von JPanel abgeleitet)
    m_bildanzeige  = new CBildLeinwand();
    add(m_bildanzeige);
  
    // Das Fenster mit einer Men�leiste versehen
    JMenuBar menueleiste = new JMenuBar();
    setJMenuBar(menueleiste);

    // Die PopupMen�s der Men�leiste erstellen
    JMenu menu1 = new JMenu("Datei");
    JMenuItem item1  = new JMenuItem("Bild laden");
    item1.addActionListener(new CMeinActionLauscher());

    JMenuItem item2 = new JMenuItem("Programm beenden");
    item2.addActionListener(new CMeinActionLauscher());
    menu1.add(item1);
    menu1.add(item2);
    menueleiste.add(menu1);

    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
  }

  // Eine Bilddatei laden
  public void bildLaden(){
    FileDialog d = new FileDialog(this,"Bilddatei laden...",
                                  FileDialog.LOAD);
    d.setVisible(true);
    m_dateiname = d.getDirectory();
    m_dateiname += d.getFile();

    // Falls der Benutzer keine Datei ausgew�hlt hat, wird null
    // zur�ckgegeben
    // Dann nichts weiter tun
    if(m_dateiname == null)
       return;

    // Bild laden 
    ImageIcon tmp = new ImageIcon(m_dateiname);
    m_aktBild = tmp.getImage(); 

    // Die Begrenzungskoordinaten des Bildes ermitteln
    m_bildBreite = m_aktBild.getWidth(m_bildanzeige);
    m_bildHoehe = m_aktBild.getHeight(m_bildanzeige);

    m_bild_x1 = m_Xpos;
    m_bild_y1 = m_Ypos;
    m_bild_x2 = m_bild_x1 + m_bildBreite;
    m_bild_y2 = m_bild_y1 + m_bildHoehe;

    m_bildanzeige.repaint();
  }

  public static void main(String[] args) {
    m_fenster = new CBildbetrachter3("Bildbetrachter");
    m_fenster.setSize(400,400);
    m_fenster.pack();
    m_fenster.setVisible(true);
  }


  // Diese Klasse dient zum Anzeigen und Manipulieren des Bildes
  class CBildLeinwand extends JPanel {

    class CMeinMausMotionAdapter extends MouseMotionAdapter {
      public void mouseDragged(MouseEvent e) {
        // lokale Variablen
        int x,y;
    
        // wenn kein Bild geladen ist, nichts tun
        if(m_aktBild == null)
          return;

        // Mauskoordinaten abfragen
        x = e.getX();
        y = e.getY();

        // Das Bild nur bewegen, wenn direkt darauf 
        // geklickt worden ist
        if(   x >= m_bild_x1 && x <= m_bild_x2 
           && y >= m_bild_y1 && y <= m_bild_y2) {

           m_Xpos = x - m_bildBreite/2;
           m_Ypos = y - m_bildHoehe/2;

           // Die neue Begrenzung berechnen und 
           // das Bild neu anzeigen
           m_bild_x1 = m_Xpos; 
           m_bild_y1 = m_Ypos;
           m_bild_x2 = m_bild_x1 + m_bildBreite;
           m_bild_y2 = m_bild_y1 + m_bildHoehe;
           repaint();
        }
      }
    } 

    CBildLeinwand (){
      addMouseMotionListener(new CMeinMausMotionAdapter());
    }
    
    // Panel neu zeichnen
    public void paintComponent(Graphics g) {
      super.paintComponent(g);

      // Falls ein Bild geladen ist, das Bild anzeigen
      if(m_aktBild != null)
        g.drawImage(m_aktBild,m_Xpos,m_Ypos,this);
    }

    public Dimension getMinimumSize() {
      return m_fenster.getSize();
    }
    public Dimension getPreferredSize() {
      return getMinimumSize();
    }
  }
}
