// Dies ist das erste Applet 

public class CHalloWWW extends java.applet.Applet  {
  public void paint(java.awt.Graphics gc)  {
    gc.drawString("Hallo World Wide Web!",100,100);
  }
}
