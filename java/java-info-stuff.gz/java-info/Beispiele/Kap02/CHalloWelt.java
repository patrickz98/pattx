// Dies ist die erste Anwendung

public class CHalloWelt {
  public static void main (String[] args) {
    System.out.println("Hallo Welt!");
  }
}
