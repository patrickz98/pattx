import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Fensterklasse definieren
public class CIcon extends JFrame {
  JButton m_schalter;

  // der Konstruktor 
  CIcon(String titel) {
    super(titel);

    setLayout(new BorderLayout());
    ImageIcon icon = new ImageIcon("buttonImage.gif");
    m_schalter =  new JButton("Klick mich", icon);
    add(m_schalter);

    // Lauscher einrichten
    m_schalter.addActionListener(new CMeinActionLauscher());

    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 
  }


  // Ereignisbehandlung f�r die Steuerelemente
  class CMeinActionLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      m_schalter.setText("Danke");      
      m_schalter.setIcon(null);      
      }
    }

  public static void main(String[] args) {
    CIcon fenster = new CIcon("Icon");
    fenster.pack();
    fenster.setSize(300,100);
    fenster.setVisible(true);
  }
}
