import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Fensterklasse definieren
public class CButton extends JFrame {
  JButton schalter;

  // der Konstruktor 
  CButton(String titel) {
    super(titel);

    setLayout(new BorderLayout());
    schalter =  new JButton("Klick mich");
    add(schalter);

    // Lauscher einrichten
    schalter.addActionListener(new CMeinActionLauscher());

    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 
  }


  // Ereignisbehandlung f�r die Steuerelemente
  class CMeinActionLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      schalter.setText("Danke");      
    }
  }

  public static void main(String[] args) {
    CButton fenster = new CButton("Schalter");
    fenster.pack();
    fenster.setSize(300,100);
    fenster.setVisible(true);
  }
}
