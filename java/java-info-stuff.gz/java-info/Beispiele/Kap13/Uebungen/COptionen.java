import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Fensterklasse definieren
public class COptionen extends JFrame {
  JCheckBox m_opt1, m_opt2, m_opt3, m_opt4;
  JRadioButton m_opt5, m_opt6, m_opt7, m_opt8;

  // der Konstruktor 
  COptionen(String titel) {
    super(titel);

    setLayout(new GridLayout(2,4,5,10));
   
    // 1. Markierungsk�stchen erzeugen
    m_opt1 = new JCheckBox ("Schaf",false);
    m_opt2 = new JCheckBox ("Ziege",false);
    m_opt3 = new JCheckBox ("Heuschrecke",false); 
    m_opt4 = new JCheckBox ("Geier",false); 

    // 2. Markierungsk�stchen in Panel aufnehmen
    add(m_opt1);
    add(m_opt2);
    add(m_opt3);
    add(m_opt4);

    // 1. Optionsfelder zur Auswahl der Formen anlegen
    ButtonGroup formauswahl = new ButtonGroup();

    // 2. Optionsfelder erzeugen
    m_opt5 = new JRadioButton ("Rot",false);
    m_opt6 = new JRadioButton ("Gr�n",false);
    m_opt7 = new JRadioButton ("Blau",false); 
    m_opt8 = new JRadioButton ("Rosa",false); 

    // 3. Befehlsnamen f�r Optionsfelder festlegen
    m_opt5.setActionCommand("Rot");
    m_opt6.setActionCommand("Gr�n");
    m_opt7.setActionCommand("Blau");
    m_opt8.setActionCommand("Rosa");

    // 4. Optionsfelder in ButtonGroup-Gruppe aufnehmen
    formauswahl.add(m_opt5);
    formauswahl.add(m_opt6);
    formauswahl.add(m_opt7);
    formauswahl.add(m_opt8);

    // 5. Optionsfelder in Panel aufnehmen
    add(m_opt5);
    add(m_opt6);
    add(m_opt7);
    add(m_opt8);

    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 

    // Lauscher einrichten
    CCheckBoxLauscher meinLauscherOpt1 = new CCheckBoxLauscher();
    m_opt1.addItemListener(meinLauscherOpt1);
    m_opt2.addItemListener(meinLauscherOpt1);
    m_opt3.addItemListener(meinLauscherOpt1);
    m_opt4.addItemListener(meinLauscherOpt1);

    CRadioLauscher meinLauscherOpt2 = new CRadioLauscher();
    m_opt5.addActionListener(meinLauscherOpt2);
    m_opt6.addActionListener(meinLauscherOpt2);
    m_opt7.addActionListener(meinLauscherOpt2);
    m_opt8.addActionListener(meinLauscherOpt2);
  }


  class CCheckBoxLauscher implements ItemListener  {
    public void itemStateChanged(ItemEvent e) {
        Object source = e.getItemSelectable();

        if (source == m_opt1) {
            JOptionPane.showMessageDialog(null,"Schaf");
        } else if (source == m_opt2) {
            JOptionPane.showMessageDialog(null,"Ziege");
        } else if (source == m_opt3) {
            JOptionPane.showMessageDialog(null,"Heuschrecke");
        } else if (source == m_opt4) {
            JOptionPane.showMessageDialog(null,"Geier");
        }
    }
  }

  class CRadioLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e) {
         String label;

         label = e.getActionCommand();
         
         if(label.equals("Rot")) {
	     JOptionPane.showMessageDialog(null,"Rot");
         } else if(label.equals("Gr�n")) {
	     JOptionPane.showMessageDialog(null,"Gr�n");
         } else if(label.equals("Blau")) {
	    JOptionPane.showMessageDialog(null,"Blau");              
         } else if(label.equals("Rosa")) {
	    JOptionPane.showMessageDialog(null,"Rosa");      
         }   
    }
  }


  public static void main(String[] args) {
    COptionen fenster = new COptionen("Optionen");
    fenster.pack();
    fenster.setSize(500,200);
    fenster.setResizable(false);
    fenster.setVisible(true);
  }
}
