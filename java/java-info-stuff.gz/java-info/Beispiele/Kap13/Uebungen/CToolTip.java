import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Fensterklasse definieren
public class CToolTip extends JFrame {
  JButton m_schalter;

  // der Konstruktor 
  CToolTip(String titel) {
    super(titel);

    setLayout(new FlowLayout());

    m_schalter =  new JButton("Klick mich");
    m_schalter.setToolTipText("Na, nun dr�ck' schon den Schalter!");

    add(m_schalter);
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 

    // Lauscher einrichten
    m_schalter.addActionListener(new CMeinActionLauscher());
  }


  // Ereignisbehandlung f�r die Steuerelemente
  class CMeinActionLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e){
      m_schalter.setText("Danke");      
    }
  }

  public static void main(String[] args) {
    CToolTip fenster = new CToolTip("Schalter mit Tooltip");
    fenster.pack();
    fenster.setSize(300,100);
    fenster.setVisible(true);
  }
}
