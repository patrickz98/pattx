import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Fensterklasse definieren
public class CText extends JFrame {

  // der Konstruktor 
  CText(String titel) {
    super(titel);

    setLayout(new BorderLayout());
   
    JPanel panel = new JPanel();
    panel.setLayout(new FlowLayout());

    JLabel l_name = new JLabel("Ihr Name: ", SwingConstants.RIGHT);
    JTextField name= new JTextField(20);
    panel.add(l_name);
    panel.add(name);

    JLabel l_passwort = new JLabel("Ihr Passwort: ", SwingConstants.RIGHT);
    JPasswordField passwort= new JPasswordField(10);
    passwort.setEchoChar('*');
    panel.add(l_passwort);
    panel.add(passwort);
    add("North",panel);

    JTextArea hilfstext = new JTextArea(" Geben Sie bitte Ihren Namen \n", 3,30);
    hilfstext.append(" und Ihr Passwort ein.\n");
    hilfstext.setEditable(false);
    hilfstext.setFont(new Font ("Monospaced",Font.BOLD,20));
    hilfstext.setBackground(Color.lightGray);
    add("Center",hilfstext);

    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 
  }


  public static void main(String[] args) {
    CText fenster = new CText("Textfelder");
    fenster.pack();
    fenster.setSize(500,200);
    fenster.setResizable(false);
    fenster.setVisible(true);
  }
}
