import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

// Fensterklasse definieren
public class CListen extends JFrame {
  DefaultListModel m_modell;

  // der Konstruktor 
  CListen(String titel) {
    super(titel);

    setLayout(new GridLayout(1,2,5,0));
   
    m_modell = new DefaultListModel();
    for(int i = 0; i < 20; i++)  {
      m_modell.addElement(new Integer(i));
    }

    JList liste = new JList(m_modell);
    liste.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    JScrollPane listenScrollPane = new JScrollPane();
    listenScrollPane.getViewport().setView(liste);
   
    String[] elemente = {"Rot", "Gr�n", "Blau", "Rosa"};
    JComboBox kombi = new JComboBox(elemente);

    add(listenScrollPane);
    add(kombi);

    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 

    // Lauscher einrichten
    ListSelectionModel lsm = liste.getSelectionModel();
    lsm.addListSelectionListener(new CListenLauscher());
    
    kombi.addActionListener(new CKombiLauscher());
  }


  // Ereignisbehandlung 
  class CMeinWindowLauscher extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
      System.exit(0);
    }
  }

  class CListenLauscher implements ListSelectionListener  {
    public void valueChanged(ListSelectionEvent e)  {
        if (e.getValueIsAdjusting())
           return;

        ListSelectionModel lsm = (ListSelectionModel) e.getSource();
        if (!lsm.isSelectionEmpty())  {
           int index = lsm.getMinSelectionIndex();
           Integer i= (Integer) m_modell.getElementAt(index);
           String str = String.valueOf(i);
           JOptionPane.showMessageDialog(null,str);
        }
     }
  }

  class CKombiLauscher implements ActionListener  {
    public void actionPerformed(ActionEvent e)  {
        JComboBox cb = (JComboBox) e.getSource();
        String str = (String)cb.getSelectedItem();
        JOptionPane.showMessageDialog(null,str);
    }
  }


  public static void main(String[] args) {
    CListen fenster = new CListen("Listen");
    fenster.pack();
    fenster.setSize(300,100);
    fenster.setResizable(false);
    fenster.setVisible(true);
  }
}
