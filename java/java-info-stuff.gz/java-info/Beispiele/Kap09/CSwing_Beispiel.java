// Das erste Swing-Programm

// Swing-Paket aufnehmen
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Fensterklasse definieren
public class CSwing_Beispiel extends JFrame {
  JButton m_h�nsel, m_und, m_gretel;


  // Ereignisbehandlung f�r die Steuerelemente
  class CMeinActionLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      int i;

      m_h�nsel.setText("verirrrrrrrrten");      
      m_und.setText("sich");      
      m_gretel.setText("im Wald");      
    }
  }

  // der Konstruktor 
  CSwing_Beispiel(String titel) {
    super(titel);

    // Schaltfl�chen erzeugen
    m_h�nsel = new JButton("H�nsel");
    m_und    = new JButton("und");
    m_gretel = new JButton("Gretel");

    // Layout-Manager zum Anordnen der Schaltfl�chen
    setLayout(new FlowLayout());

    // Schaltfl�chen in Fenster aufnehmen
    add(m_h�nsel);
    add(m_und);
    add(m_gretel);


    // Anwendung schlie�en wenn Fenster geschlossen wird
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 

    // Schaltfl�chen bei ActionListener registrieren
    m_h�nsel.addActionListener(new CMeinActionLauscher());
    m_und.addActionListener(new CMeinActionLauscher());
    m_gretel.addActionListener(new CMeinActionLauscher());
  }


  public static void main(String[] args) {
    CSwing_Beispiel fenster = new CSwing_Beispiel("Swing");
    fenster.pack();
    fenster.setSize(300,100);
    fenster.setVisible(true);
  }
}
