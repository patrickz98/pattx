import java.awt.*;
import java.awt.event.*;

// Fensterklasse definieren
public class CAWT_zu_Swing1 extends Frame {
  Button schalter;

  // Ereignisbehandlung f�r das Fenster 
  class CMeinWindowLauscher extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
      System.exit(0);
    }
  }

  // Ereignisbehandlung f�r die Steuerelemente
  class CMeinActionLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      schalter.setLabel("Danke");      
    }
  }

  // der Konstruktor 
  CAWT_zu_Swing1(String titel) {
    super(titel);

    // Schaltfl�che  erzeugen
    schalter = new Button("Klick mich");

    // Schaltfl�che  in Fenster aufnehmen
    add(schalter);

    // Fenster schlie�en = Anwendung schlie�en     
    addWindowListener(new CMeinWindowLauscher());

    // die Schaltfl�che  bei einem ActionListener registrieren
    schalter.addActionListener(new CMeinActionLauscher());
  }


  public static void main(String[] args) {
    CAWT_zu_Swing1 fenster = new CAWT_zu_Swing1("AWT");
    fenster.pack();
    fenster.setSize(300,100);
    fenster.setVisible(true);
  }
}
