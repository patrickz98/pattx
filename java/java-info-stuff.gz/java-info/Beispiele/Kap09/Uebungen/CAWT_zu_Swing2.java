import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Fensterklasse definieren
public class CAWT_zu_Swing2 extends JFrame {
  JButton schalter;


  // Ereignisbehandlung f�r die Steuerelemente
  class CMeinActionLauscher implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      schalter.setText("Danke");      
    }
  }

  // der Konstruktor 
  CAWT_zu_Swing2(String titel) {
    super(titel);

    // Schaltfl�che  erzeugen
    schalter = new JButton("Klick mich");

    // Schaltfl�che  in Fenster aufnehmen
    add(schalter);

    // Fenster schlie�en = Anwendung schlie�en    
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 

    // die Schaltfl�che  bei einem ActionListener registrieren
    schalter.addActionListener(new CMeinActionLauscher());
  }


  public static void main(String[] args) {
    CAWT_zu_Swing2 fenster = new CAWT_zu_Swing2("Swing");
    fenster.pack();
    fenster.setSize(300,100);
    fenster.setVisible(true);
  }
}
