// Der Fleckengenerator mit Parameter
import java.awt.*;
import java.applet.*;

public class CSpot_mit_Parametern extends Applet {
  class CScheibe {
    int m_x, m_y; // Mittelpunkt
    int m_r;      // Radius
  }

  CScheibe[] m_flecken;
  Color m_farbe;


  public CSpot_mit_Parametern() {
  }

  public void init() {
     String parameter = getParameter("Anzahl");
     int anzahl = Integer.parseInt(parameter);
     m_flecken = new CScheibe[anzahl];
     for(int i = 0; i < m_flecken.length; i++) 
       m_flecken[i] = new CScheibe();

     String farbe = getParameter("Farbe").toUpperCase();
     if (farbe.equals("ROT"))
        m_farbe = new Color (255, 0, 0);
     else if (farbe.equals("BLAU"))
        m_farbe = new Color (0, 0, 255);
     else if (farbe.equals("GRUEN"))
        m_farbe = new Color (0, 255, 0);
     else if (farbe.equals("GELB"))
        m_farbe = new Color (255, 255, 0);
     else 
        m_farbe = new Color (0, 0, 0);
  }


  public void start() {
    //Mittelpunkte und Radien festlegen
    for(int i = 0; i < m_flecken.length; i++) {
       m_flecken[i].m_x = (int) (400*Math.random()); 
       m_flecken[i].m_y = (int) (200*Math.random()); 
       m_flecken[i].m_r = (int) (50*Math.random());
    }
  }


  public void paint(Graphics g) {
    g.setColor(m_farbe);
    for(int i = 0; i < m_flecken.length; i++) {
       g.fillOval(m_flecken[i].m_x, 
                  m_flecken[i].m_y, 
                  m_flecken[i].m_r, 
                  m_flecken[i].m_r);
    }
  }
} 
