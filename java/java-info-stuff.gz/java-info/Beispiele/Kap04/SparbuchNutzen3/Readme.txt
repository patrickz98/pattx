Bevor Sie CSparbuchNutzen3.java kompilieren, m�ssen Sie zuerst 
in das Unterverzeichnis zinsrechnung wechseln und dort 
die Datei CSparbuch.java kompilieren.

Danach k�nnen Sie CSparbuchNutzen3.java wie gewohnt kompilieren und ausf�hren:

javac CSparbuchNutzen3.java
java CSparbuchNutzen3
