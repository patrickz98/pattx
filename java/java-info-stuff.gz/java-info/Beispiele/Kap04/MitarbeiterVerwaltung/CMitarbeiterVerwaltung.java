// class-Datei CMitarbeiter.class muss in gleichem 
// Verzeichnis stehen

public class CMitarbeiterVerwaltung {
  public static void main(String[] args) {
    CMitarbeiter[] personalliste = new CMitarbeiter[4];
    int mitarbeiterzahl;  

    personalliste[0] = new CMitarbeiter("Marx","Groucho",8000);  
    personalliste[1] = new CMitarbeiter("Marx","Chico",7000);  
    personalliste[2] = new CMitarbeiter("Marx","Harpo",7000);  
    personalliste[3] = new CMitarbeiter("Marx","Zeppo",7000);  
    mitarbeiterzahl = 4;  

    // alle Mitarbeiter ausgeben
    for(int i = 0; i < personalliste.length; i++)
      personalliste[i].datenAusgeben();
  }
}
