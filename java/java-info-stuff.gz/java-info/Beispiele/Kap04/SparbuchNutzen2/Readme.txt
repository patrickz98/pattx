Bevor Sie CSparbuchNutzen2.java kompilieren, m�ssen Sie im �bergeordneten
Verzeichnis CSparbuchNutzen1.java kompilieren und die class-Datei 
CSparbuch.class in dieses Verzeichnis kopieren.

Danach k�nnen Sie CSparbuchNutzen2.java wie gewohnt kompilieren und ausf�hren:

javac CSparbuchNutzen2.java
java CSparbuchNutzen2
