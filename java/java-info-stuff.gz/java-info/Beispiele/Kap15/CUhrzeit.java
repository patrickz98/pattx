// funktionierendes Uhrzeit-Applet
import java.util.Date;   
import java.text.*;      
import java.applet.*;
import java.awt.*;

public class CUhrzeit extends Applet {
  String m_aktZeit;
  DateFormat m_formatierer;
  CZeitThread m_zeit;
  Font m_anzeigeFont;

  public void init()   {
    m_anzeigeFont = new Font("Serif",Font.BOLD,22);
    m_formatierer = DateFormat.getTimeInstance();
    m_aktZeit = m_formatierer.format(new Date());

    // eine Instanz der Thread-Klasse anlegen und starten
    m_zeit = new CZeitThread();
    m_zeit.start();
  }

  public void start()   {
    // einen Thread starten
    if(m_zeit == null) {
      m_zeit = new CZeitThread();
      m_zeit.start();
    }
  }

  public void stop() {
    // den Thread beenden
    if(m_zeit != null) {
      m_zeit.interrupt();
      m_zeit = null;
    }
  }

  public void destroy() {
    // den Thread beenden
    if(m_zeit != null) {
      m_zeit.interrupt();
      m_zeit = null;
    }
  }

  public void paint(Graphics g) {
    // die aktuelle Uhrzeit anzeigen
    g.setFont(m_anzeigeFont);
    g.setColor(Color.blue);
    g.drawString(m_aktZeit,20,45);
  }

  // den Thread als innere Klasse definieren
  class CZeitThread extends Thread {
    public void run()  {
      while(isInterrupted() == false) {
        m_aktZeit = m_formatierer.format(new Date());
        repaint();

        // kurze Zeit schlafen
        try {
          sleep(1000); 
        } 
        catch(InterruptedException e)  {
          return;
        }
      }
    }
  }
}
