import java.util.Date;   
import java.text.*;      
import java.applet.*;
import java.awt.*;

public class CUhrzeit_Parameter extends Applet {
  String m_aktZeit;
  DateFormat m_formatierer;
  CZeitThread m_zeit;
  Font m_anzeigeFont;

  public void init()   {
    String Parameter;
    Parameter = getParameter("Datum/Zeit");

    if (Parameter.equals("Zeit"))
       m_formatierer = DateFormat.getTimeInstance();
    else
       m_formatierer = DateFormat.getDateInstance();

    m_anzeigeFont = new Font("Serif",Font.BOLD,22);
    m_aktZeit = m_formatierer.format(new Date());

    // eine Instanz der Threadklasse anlegen und starten
    m_zeit = new CZeitThread();
    m_zeit.start();
  }

  public void start()   {
    // einen Thread starten
    if(m_zeit == null) {
      m_zeit = new CZeitThread();
      m_zeit.start();
    }
  }

  public void stop() {
    // den Thread beenden
    if(m_zeit != null) {
      m_zeit.interrupt();
      m_zeit = null;
    }
  }

  public void destroy() {
    // den Thread beenden
    if(m_zeit != null) {
      m_zeit.interrupt();
      m_zeit = null;
    }
  }

  public void paint(Graphics g) {
    // die aktuelle Uhrzeit anzeigen
    g.setFont(m_anzeigeFont);
    g.setColor(Color.blue);
    g.drawString(m_aktZeit,20,45);
  }

  // den Thread als innere Klasse definieren
  class CZeitThread extends Thread {
    public void run()  {
      while(isInterrupted() == false) {
        m_aktZeit = m_formatierer.format(new Date());
        repaint();

        // kurze Zeit schlafen
        try {
          sleep(1000); 
        } 
        catch(InterruptedException e)  {
          return;
        }
      }
    }
  }
}
