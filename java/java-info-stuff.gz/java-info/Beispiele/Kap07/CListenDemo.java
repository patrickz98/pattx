import java.util.*;
import java.io.*;

class CItem {
  String m_name;
  int m_nummer;

  // der Konstruktor 
  CItem(String derName,int dieNummer) {
    m_name = derName;
    m_nummer = dieNummer; 
  }
}

public class CListenDemo {
  public static void main(String []args) {
    // eine Liste anlegen und einige Namen ans Ende einf�gen
    LinkedList<CItem> freunde = new LinkedList<CItem>();

    CItem aktuell = new CItem("Dirk",455689);
    freunde.add(aktuell);  // ans Ende anh�ngen

    aktuell = new CItem("Peter",543679);
    freunde.add(aktuell); // ans Ende anh�ngen

    // Objekt direkt erzeugen und anh�ngen
    freunde.add(new CItem("Katja",238590)); 

    // Objekt direkt erzeugen und vorne einf�gen
    freunde.add(0, new CItem("Julia",749326)); 


    // den Inhalt der Liste auf drei verschiedene Arten ausgeben
    Console cons = System.console();

    cons.printf("\n Ausgabe mit get() \n"); 
    for(int i = 0; i < freunde.size(); i++) {
      aktuell = freunde.get(i);
      cons.printf(" %s %d\n", aktuell.m_name, aktuell.m_nummer);
    }

    cons.printf ("\n Ausgabe mit Iterator \n"); 
    Iterator<CItem> it = freunde.iterator();
    while(it.hasNext()) {
      aktuell =  it.next();
      cons.printf(" %s %d\n", aktuell.m_name, aktuell.m_nummer);
    }

    cons.printf ("\n Ausgabe mit for \n"); 
    for(CItem akt : freunde) {
      cons.printf(" %s %d\n", akt.m_name, akt.m_nummer);
    }
  }
}
