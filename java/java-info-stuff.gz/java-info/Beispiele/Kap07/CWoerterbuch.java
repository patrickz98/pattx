import java.util.*; 
import java.io.*; 

class CItem {
  String m_wort,m_typ;

  CItem(String w,String t) {
    m_wort = w;
    m_typ = t; 
  }
}

public class CWoerterbuch {
  public static void main(String args[]) {
    Console cons = System.console();
    cons.printf("\n");
    
    HashMap<String,CItem> tabelle = new HashMap<String,CItem>();
    tabelle.put("gehen",new CItem("walk","Verb"));
    tabelle.put("laufen",new CItem("run","Verb"));
    tabelle.put("schwimmen", new CItem("swim","Verb"));
    tabelle.put("Rei�verschluss", new CItem("zipper","Nomen"));

    // nach einem Wort suchen 
    Scanner tastatur = new Scanner(cons.reader()); 
    cons.printf(" Deutsches Wort: ");
    String suchString = tastatur.next(); 

    // In Hashtabelle nachschlagen
    CItem ergebnis = tabelle.get(suchString); 

    if(ergebnis == null)
       cons.printf(" %s nicht gefunden! \n", suchString); 
    else
       cons.printf(" %s heisst auf Englisch %s \n",
                   suchString, ergebnis.m_wort); 
    }
} 

