// Einsatz des Zufallszahlengenerators
import java.util.*;

class CLotto {
  public static void main(String args[]) {
    int zahl;
    int anzahl = 0; 
    Random generator = new Random(); 
    
    System.out.println("\n Die Ziehung der Lottozahlen \n");
    
    while(true) {
      // Zahl zwischen 0 (inkl.) und 50 (exkl.)
      zahl = generator.nextInt(50); 
      if(zahl == 0)
      // 0 brauchen wir nicht 
        continue;

      // Zahl ausgeben 
      System.out.println(" Gezogene Zahl: " + zahl); 
      
      // Sind 6 Zahlen gezogen worden? Dann Ende.
      anzahl++;

      if(anzahl == 6)
        break; 
    }
  }
}