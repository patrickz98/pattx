// Umdrehen der Buchstaben eines Wortes
import java.util.*;
import java.io.*; 

class CUmdrehen {
  public static void main(String [] args) {
    Console cons = System.console();
    cons.printf("\n");
    
    cons.printf(" Text eingeben: "); 
    String eingabeWort = cons.readLine();

    int anzahl = eingabeWort.length(); 

    // Die Buchstaben in einen Keller einf�gen
    Stack<Character> keller = new Stack<Character>();
    for(int i = 0; i < anzahl; i++) {
      keller.push(eingabeWort.charAt(i)); 
    }

    // Elemente vom Stack entfernen und ausgeben
    cons.printf(" Umgedreht    : "); 
    for(int i = 0; i < anzahl; i++) {
      cons.printf("%s", keller.pop());
    }
    
    cons.printf("\n"); 
  }
}
